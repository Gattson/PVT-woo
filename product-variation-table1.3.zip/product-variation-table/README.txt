Incase i have to state it, this was made for my personal use BUT I'm posting the code here for anyone in case they want a license free alternative to existing plugins.

HOW TO USE: Just drag and drop the ZIP into wordpress plugins installer. 
CUSTOMIZE: THE ONLY customizable features currently are what columns are visible. you can toggle them on and off in settings --> variations table
KNOWN BUGS: Currently some instances are having trouble with AJAX carts. If its a popup cart, it wont open unless a user is logged in.
UNKOWN BUGS: I DONT KNOW HELP ME PLEASE. No seriously if you encounter any bugs let me know. NOT TO BE CONFUSED WITH CUSTOMIZING.

There is no license for this product. completely free to use. very basic functionally but gets the job done. 